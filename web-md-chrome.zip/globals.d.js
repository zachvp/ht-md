"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/globals.d.ts
  var require_globals_d = __commonJS({
    "src/globals.d.ts"() {
    }
  });
  require_globals_d();
})();
