"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/background.ts
  var require_background = __commonJS({
    "src/background.ts"() {
      console.log("[web-md] background loaded");
      var DEFAULT_ACTION = "activatePicker";
      var handlers = {
        activatePicker(tab) {
          console.log("[web-md] sending activate to tab", tab.id, tab.url);
          chrome.tabs.sendMessage(tab.id, { action: "activate" }).catch((err) => console.warn("[web-md] activatePicker:", err.message));
        }
      };
      chrome.action.onClicked.addListener((tab) => {
        console.log("[web-md] toolbar clicked, tab:", tab.id);
        chrome.storage.sync.get({ toolbarAction: DEFAULT_ACTION }).then(({ toolbarAction }) => {
          console.log("[web-md] dispatching action:", toolbarAction);
          const handler = handlers[toolbarAction] ?? handlers[DEFAULT_ACTION];
          handler(tab);
        });
      });
    }
  });
  require_background();
})();
