"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // src/content.ts
  var require_content = __commonJS({
    "src/content.ts"() {
      console.log("[web-md] content script loaded");
      var pickerActive = false;
      var lastHighlighted = null;
      var lastMousePos = { x: 0, y: 0 };
      var flashEl = null;
      var flashMoveHandler = null;
      var selectedElements = [];
      var selectedSet = /* @__PURE__ */ new Set();
      var turndown = new TurndownService();
      turndown.remove(["style", "script", "noscript"]);
      function activatePicker() {
        if (pickerActive) return;
        pickerActive = true;
        console.log("[web-md] picker activated");
        document.addEventListener("mouseover", onMouseOver);
        document.addEventListener("click", onClick, true);
        document.addEventListener("keydown", onKeyDown, true);
      }
      function deactivatePicker() {
        if (!pickerActive) return;
        pickerActive = false;
        console.log("[web-md] picker deactivated");
        lastHighlighted?.classList.remove("web-md-highlight");
        lastHighlighted = null;
        for (const el of selectedElements) el.classList.remove("web-md-selected");
        selectedElements.length = 0;
        selectedSet.clear();
        document.removeEventListener("mouseover", onMouseOver);
        document.removeEventListener("click", onClick, true);
        document.removeEventListener("keydown", onKeyDown, true);
      }
      function onMouseOver(e) {
        lastMousePos = { x: e.clientX, y: e.clientY };
        lastHighlighted?.classList.remove("web-md-highlight");
        const target = e.target;
        if (target === document.body || target === document.documentElement) return;
        lastHighlighted = target;
        lastHighlighted.classList.add("web-md-highlight");
      }
      function onClick(e) {
        e.preventDefault();
        e.stopPropagation();
        const el = e.target;
        if (el === document.body || el === document.documentElement) {
          deactivatePicker();
          return;
        }
        if (e.metaKey) {
          if (!selectedSet.has(el)) {
            selectedElements.push(el);
            selectedSet.add(el);
            el.classList.add("web-md-selected");
          }
          showFlash(`${selectedElements.length} selected \u2014 Enter to copy`, e.clientX, e.clientY);
          return;
        }
        const html = el.outerHTML;
        const md = turndown.turndown(html);
        console.log("[web-md] captured element:", el.tagName, "\u2014 md length:", md.length);
        navigator.clipboard.writeText(md).then(() => {
          console.log("[web-md] clipboard write ok");
          showFlash("\u{1F4DD} Copied", e.clientX, e.clientY);
        }).catch((err) => {
          console.error("[web-md] clipboard write failed:", err.message);
          showFlash("Error: " + err.message, e.clientX, e.clientY);
        });
        deactivatePicker();
      }
      function onKeyDown(e) {
        if (e.key === "Escape") {
          e.stopPropagation();
          deactivatePicker();
        } else if (e.key === "Enter" && selectedElements.length > 0) {
          e.preventDefault();
          e.stopPropagation();
          const md = selectedElements.map((el) => turndown.turndown(el.outerHTML)).join("\n");
          console.log("[web-md] committing", selectedElements.length, "elements \u2014 md length:", md.length);
          navigator.clipboard.writeText(md).then(() => {
            console.log("[web-md] clipboard write ok");
            showFlash("\u{1F4DD} Copied", lastMousePos.x, lastMousePos.y);
          }).catch((err) => {
            console.error("[web-md] clipboard write failed:", err.message);
            showFlash("Error: " + err.message, lastMousePos.x, lastMousePos.y);
          });
          deactivatePicker();
        }
      }
      function showFlash(text, x, y) {
        if (flashEl) {
          flashEl.remove();
          if (flashMoveHandler) document.removeEventListener("mousemove", flashMoveHandler);
        }
        const el = document.createElement("div");
        el.className = "web-md-flash";
        el.textContent = text;
        el.style.left = "0";
        el.style.top = "0";
        document.body.appendChild(el);
        const pad = 8;
        const w = el.offsetWidth;
        const h = el.offsetHeight;
        function position(cx, cy) {
          el.style.left = `${Math.min(Math.max(cx - w / 2, pad), window.innerWidth - w - pad)}px`;
          el.style.top = `${Math.min(Math.max(cy + 12, pad), window.innerHeight - h - pad)}px`;
        }
        position(x, y);
        flashEl = el;
        flashMoveHandler = (e) => position(e.clientX, e.clientY);
        document.addEventListener("mousemove", flashMoveHandler);
        setTimeout(() => {
          el.remove();
          document.removeEventListener("mousemove", flashMoveHandler);
          if (flashEl === el) {
            flashEl = null;
            flashMoveHandler = null;
          }
        }, 1500);
      }
      chrome.runtime.onMessage.addListener((msg) => {
        console.log("[web-md] message received:", msg);
        if (msg.action === "activate") activatePicker();
      });
    }
  });
  require_content();
})();
